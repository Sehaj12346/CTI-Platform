# Cloud-Based Cyber Threat Intelligence (CTI) Platform

Flask-based CTI prototype integrating authentication, client/admin portals, CVE processing, AWS CTI processing, security monitoring, support, and Scenario 4 suspicious-file analysis.

## Features
- User login and registration with role-based portal access
- Critical CVE workflow and AWS Lambda/API Gateway CTI processing
- CloudWatch-based security Log Watch (administrator access)
- Scenario 4 file upload (maximum 10 MB), SHA-256 hashing, VirusTotal hash lookup, and private Amazon S3 quarantine
- Support and threat search templates

## Requirements
- Python 3.10+
- AWS credentials/role permitted to access the configured services
- VirusTotal API key for Scenario 4 hash lookups

## Local setup (PowerShell)
```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
$env:SECRET_KEY = "replace-with-a-long-random-secret"
$env:VT_API_KEY = "your-VirusTotal-key"
$env:CTI_QUARANTINE_BUCKET = "cti-malware-quarantine-sk-2026"
# Set temporary AWS Academy credentials in the current PowerShell session if required.
python app.py
```
Open http://127.0.0.1:5000.

Never commit `.env`, AWS credentials, session tokens, VirusTotal API keys, security logs, or uploaded files. Scenario 4 checks the SHA-256 hash only; it does not upload the file to VirusTotal or execute it. `UNKNOWN` means no existing report was found and must not be interpreted as safe.

## Configuration
- `VT_API_KEY`: VirusTotal API key (optional; if missing, the file is still quarantined and the UI reports that lookup was not performed)
- `CTI_QUARANTINE_BUCKET`: S3 quarantine bucket name (default `cti-malware-quarantine-sk-2026`)
- `SECRET_KEY` or `FLASK_SECRET_KEY`: Flask session secret
- `AWS_DEFAULT_REGION`: AWS region override if needed (application currently configures AWS clients for `us-east-1`)

## Important
This is an academic prototype, not a production malware sandbox. Uploaded files are stored in S3 quarantine and are never executed by this application.
